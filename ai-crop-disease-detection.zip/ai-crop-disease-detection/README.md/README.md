\# 🌾 AI-Driven Crop Disease Prediction and Management System



This project uses \*\*ESP32-CAM\*\*, \*\*deep learning\*\*, and \*\*Twilio API\*\* to detect rice crop diseases and notify farmers via SMS with pesticide suggestions.



Key Features

\- ESP32-CAM captures crop images

\- Image sent to cloud using Ngrok

\- Google Colab with Flask and TResNet predicts disease

\- SMS alert sent if crop is infected



Technologies Used

\- ESP32-CAM (Arduino C++)

\- Python, Flask, TensorFlow, OpenCV

\- Google Colab

\- Twilio API

\- Ngrok Tunnel



&nbsp;How It Works

1\. ESP32-CAM captures image every 15 seconds.

2\. Sends image to Colab Flask server.

3\. TResNet model detects disease.

4\. Sends SMS to farmer using Twilio.



Model Used

\- model.h5 – TResNet deep learning model trained on rice leaf diseases.





